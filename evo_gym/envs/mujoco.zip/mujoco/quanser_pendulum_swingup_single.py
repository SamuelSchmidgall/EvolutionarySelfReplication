import os
import math
import mujoco_py
import numpy as np
from gym import utils
from gym import spaces
from copy import deepcopy
from gym.envs.mujoco import mujoco_env



def calculate_upright_angle(alpha):
    a = alpha % (2 * np.pi) + -np.pi
    return a


class QuanserPendulumSwingupSingleEnv(mujoco_env.MujocoEnv, utils.EzPickle):

    def __init__(self, timestep=None):
        self.prev_r = 0
        self.forces = 0
        self.act_diff = 0
        self.timestep = 0
        self.prev_time = 0
        self.prev_action = 0
        self.theta_state = 0
        self.alpha_state = 0
        self.prev_upright = 0
        self.random_scalar = 1
        self.previous_state1 = np.zeros(7)
        self.previous_state2 = np.zeros(7)
        self.unique_id = np.random.randint(0, 99999)

        self.prev_theta = np.zeros(2)
        model_path = 'quanser_pendulum_single.xml'
        if timestep is not None:
            if model_path.startswith("/"):
                fullpath = model_path
            else:
                fullpath = os.path.join(os.path.dirname(__file__), "assets", model_path)

            model_path = self.generate_new_ts_model(fullpath, timestep)

        mujoco_env.MujocoEnv.__init__(self, model_path, 1)
        utils.EzPickle.__init__(self)


        self.action_space = spaces.Box(low=-1*np.ones(1), high=np.ones(1))

        obs_high = np.array([ 1,  1,  1,  1,  1])
        obs_low  = np.array([-1, -1, -1, -1, -1])
        self.observation_space = spaces.Box(low=obs_low, high=obs_high)


    def step(self, action):
        try:
            self.alpha_state = self.alpha_state
        except Exception:
            self.prev_r = 0.0
            self.timestep = 0
            self.prev_time = 0
            self.theta_state = 0
            self.alpha_state = 0
            self.prev_theta = np.zeros(2)
            self.base_timestep = self.model.opt.timestep

        K_T = 0.0077
        multiplier = 3*8
        voltage_in = np.clip(action, a_min=-8, a_max=8) * multiplier
        torque = K_T * voltage_in

        self.prev_theta = deepcopy(self.data.qpos)
        self.do_simulation(torque, self.frame_skip)

        self.timestep += 1
        power_in = action
        if type(power_in) == np.ndarray and len(power_in.shape) > 0:
            power_in = power_in[0]

        state = self._get_obs(power_in)

        reward, game_over = self.get_reward()
        self.prev_r = reward

        return state, reward, game_over, {'forces_added': None}

    def get_reward(self,):
        game_over = False
        upright = calculate_upright_angle(-(self.data.qpos[1] + -np.pi))
        upright_distance = abs((3.14 - abs(upright)))
        reward =  1 + upright_distance

        if abs(upright) < 0.3:
            reward = 5

        if abs(self.data.qpos[0]) > 2.0:
            reward = -10
            game_over = True

        return reward, game_over

    def filt_der(self, theta, alpha):
        K = 1.0
        Ts = self.model.opt.timestep
        T = 1.0 / (2*math.pi*10.0)  # <-- defined in pend docs

        x_n_t = self.theta_state  # theta 0
        self.theta_state = x_n_t * (1 - Ts / T) + theta * (Ts / T)
        theta_dot = (K / T) * (theta - x_n_t)

        a_n_t = self.alpha_state  # theta 1
        self.alpha_state = a_n_t * (1 - Ts / T) + alpha * (Ts / T)
        alpha_dot = (K / T) * (alpha - a_n_t)

        X = np.array([theta_dot, alpha_dot])

        return X

    def _get_obs(self, power_in):
        joint_pos = deepcopy(self.data.qpos)

        self.prev_theta = joint_pos
        self.prev_time = self.data.time

        upright_angle = calculate_upright_angle(-(self.data.qpos[1] + -np.pi))
        joint_pos[1] = upright_angle
        state = np.append(
            np.array([joint_pos]), np.array([power_in]))

        fd = np.clip(self.filt_der(joint_pos[0], joint_pos[1]), a_max=20, a_min=-20)

        state = np.append(state, fd)

        state[0] /= 2.0
        state[1] = state[1] / 4.0
        state[2] = state[2] / 1.0
        state[3] = state[3] / 20.0
        state[4] = state[4] / 20.0

        state = np.clip(state, a_min=-1, a_max=1)
        return state

    def reset_model(self):
        self.theta_state = 0
        self.alpha_state = 0

        self.prev_time = 0.0
        self.prev_theta = np.zeros(2)


        self.timestep = 0
        w = np.random.uniform(-0.4, 0.4)
        rnd_pos = [np.random.uniform(
            -1*(3.14+0.5), -1*(3.14-0.5)), np.random.uniform(3.14+0.5, 3.14-0.5)]
        ch = np.random.choice([0, 1], p=[0.5, 0.5])
        v = rnd_pos[ch]
        rnd_vel = self.init_qvel
        self.set_state(
            np.array([w, v]),
            rnd_vel
        )
        obs = self._get_obs(0.0)

        return obs

    def clear_data(self):
        import os
        if os.path.exists(r"C:\Users\sschmidgall\Desktop\For Sam"
                          r"\gym\gym\envs\mujoco\assets\quanser_pendulum_singleCP{}.xml".format(self.unique_id)):
            os.remove(r"C:\Users\sschmidgall\Desktop\For Sam"
                      r"\gym\gym\envs\mujoco\assets\quanser_pendulum_singleCP{}.xml".format(self.unique_id))
        else:
            print("The file does not exist")

    def reload_XML(self, new_ts, new_mass):
        with open(r"C:\Users\sschmidgall\Desktop\For Sam\gym\gym\envs\mujoco\assets\quanser_pendulum_singleCP.xml", "r") as f:
            content = f.read()
        model = content
        model = model.replace("timestep=\"{}\"".format(self.base_timestep), "timestep=\"{}\"".format(round(new_ts, 5)))
        model = model.replace("mass=\"{}\"".format(self.base_body_mass[1]), "mass=\"{}\"".format(new_mass[1]))
        model = model.replace("mass=\"{}\"".format(self.base_body_mass[2]), "mass=\"{}\"".format(new_mass[2]))

        with open(r"C:\Users\sschmidgall\Desktop\For Sam"
                  r"\gym\gym\envs\mujoco\assets\quanser_pendulum_singleCP{}.xml".format(self.unique_id), "w") as f:
            f.write(model)
        self.model = mujoco_py.load_model_from_path(
            r"C:\Users\sschmidgall\Desktop\For Sam"
            r"\gym\gym\envs\mujoco\assets\quanser_pendulum_singleCP{}.xml".format(self.unique_id))

    def viewer_setup(self):
        v = self.viewer
        v.cam.trackbodyid = 0
        v.cam.distance = self.model.stat.extent * 0.5
        v.cam.lookat[2] = 0.12250000000000005  # v.model.stat.center[2]

    def generate_new_ts_model(self, path, ts):
        with open(path, 'r') as f:
            document = f.read()
        document = document.replace('<option timestep="0.002"/>', '<option timestep="{}"/>'.format(ts))
        path = path.replace('quanser_pendulum_single', 'quanser_pendulum_single_MOD')
        with open(path, 'w') as f:
            f.write(document)
        return path

