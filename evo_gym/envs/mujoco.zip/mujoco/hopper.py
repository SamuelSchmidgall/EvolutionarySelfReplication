import numpy as np
from gym import utils
from gym import spaces
from gym.envs.mujoco import mujoco_env

class HopperEnv(mujoco_env.MujocoEnv, utils.EzPickle):
    def __init__(self, timestep):
        mujoco_env.MujocoEnv.__init__(self, 'hopper.xml', 4)
        utils.EzPickle.__init__(self)
        obs_high = np.ones(12)
        obs_low  = -1*np.ones(12)

        self.observation_space = spaces.Box(low=obs_low, high=obs_high)

    def step(self, a, observation_noise=0.0, action_noise=0.0):
        # make a graph showing the degradation in performance as a function of the noise STD
        posbefore = self.sim.data.qpos[0]
        a += action_noise*np.random.uniform(-1, 1, a.shape)

        self.do_simulation(a, self.frame_skip)
        posafter, height, ang = self.sim.data.qpos[0:3]

        alive_bonus = 1.0
        reward = (posafter - posbefore) / self.dt
        reward += alive_bonus
        reward -= 1e-3 * np.square(a).sum()
        s = self.state_vector()
        done = not (np.isfinite(s).all() and (np.abs(s[2:]) < 100).all() and
                    (height > .7) and (abs(ang) < .2))
        ob = self._get_obs()
        #ob += observation_noise*np.random.uniform(-1, 1, ob.shape)
        ob = np.round(ob, 3)
        return ob, reward, done, {}

    def _get_obs(self):
        # 1.0 -> -0.1
        # 1.3 -> 0.6
        # 0.2, -0.2
        # 0.1 -> -1.4
        # 0.1 -> -1
        # 0.9 -> -0.1
        # 0.2 -> -0.2
        # 0.2 -> -0.2
        # 0.3 -> -0.3
        joint_subtractor = np.array([
            0.5, 1.05, 0.0, -0.75, -0.55, 0.4,
        ])
        joint_divisor = np.array([
            0.6, 0.45, 0.2,   0.85,  0.65, 0.6,
        ])

        return np.concatenate([
            (self.sim.data.qpos.flat[:] - joint_subtractor)/joint_divisor,#, a_max=1, a_min=-1),
            np.clip(self.sim.data.qvel.flat[:], a_min=-10, a_max=10)/10,
        ])

    def reset_model(self):
        qpos = self.init_qpos + self.np_random.uniform(low=-.005, high=.005, size=self.model.nq)
        qvel = self.init_qvel + self.np_random.uniform(low=-.005, high=.005, size=self.model.nv)
        self.set_state(qpos, qvel)
        return self._get_obs()

    def viewer_setup(self):
        self.viewer.cam.trackbodyid = 2
        self.viewer.cam.distance = self.model.stat.extent * 0.75
        self.viewer.cam.lookat[2] = 1.15
        self.viewer.cam.elevation = -20
