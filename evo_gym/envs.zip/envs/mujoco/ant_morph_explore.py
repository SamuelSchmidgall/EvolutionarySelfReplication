import numpy as np
from gym import utils
from gym.envs.mujoco import mujoco_env

class AntMorphExploreEnv(mujoco_env.MujocoEnv, utils.EzPickle):
    def __init__(self):
        random_legs_size = np.random.uniform(low=0.7, high=1.3, size=(4,))
        self.iter = 0
        self.eval_itr = 100
        self.randomize_antmorph(random_legs_size)
        mujoco_env.MujocoEnv.__init__(self, 'ant_morph.xml', 5)
        utils.EzPickle.__init__(self)

    def step(self, a):
        xposbefore = self.get_body_com("torso")[0]
        self.do_simulation(a, self.frame_skip)
        xposafter = self.get_body_com("torso")[0]
        forward_reward = (xposafter - xposbefore)/self.dt
        ctrl_cost = .5 * np.square(a).sum()
        contact_cost = 0.5 * 1e-3 * np.sum(
            np.square(np.clip(self.sim.data.cfrc_ext, -1, 1)))
        survive_reward = 1.0
        reward = self.data.body_xvelp[1][0] if self.iter >= self.eval_itr else 0.0
        state = self.state_vector()
        notdone = np.isfinite(state).all()
        self.iter += 1

        done = not notdone
        ob = self._get_obs()
        return ob, reward, done, dict(
            reward_forward=forward_reward,
            reward_ctrl=-ctrl_cost,
            reward_contact=-contact_cost,
            reward_survive=survive_reward)

    def _get_obs(self):
        return np.concatenate([
            self.sim.data.qpos.flat[2:],
            self.sim.data.qvel.flat,
            #np.clip(self.sim.data.cfrc_ext, -1, 1).flat,
        ])

    def alive_bonus(self, z, pitch):
        return +1 if z > 0.26 else -1  # 0.25 is central sphere rad, die if it scrapes the ground

    def reset_model(self):
        self.iter = 0
        random_legs_size = np.random.uniform(low=0.7, high=1.3, size=(4,))
        self.randomize_antmorph(random_legs_size)
        mujoco_env.MujocoEnv.__init__(self, 'ant_morph.xml', 5)
        qpos = self.init_qpos + self.np_random.uniform(size=self.model.nq, low=-.1, high=.1)
        qvel = self.init_qvel + self.np_random.randn(self.model.nv) * .1
        self.set_state(qpos, qvel)
        return self._get_obs()

    def randomize_antmorph(self, random_legs_size):

        path = "/home/sam/PycharmProjects/virtual_envs/spiking/lib/python3.6/site-packages/gym/gym/envs/mujoco/assets/ant.xml"
        geom1_orig = """
      <body name="front_left_leg" pos="0 0 0">
        <geom fromto="0.0 0.0 0.0 0.2 0.2 0.0" name="aux_1_geom" size="0.08" type="capsule"/>
        <body name="aux_1" pos="0.2 0.2 0">
          <joint axis="0 0 1" name="hip_1" pos="0.0 0.0 0.0" range="-30 30" type="hinge"/>
          <geom fromto="0.0 0.0 0.0 0.2 0.2 0.0" name="left_leg_geom" size="0.08" type="capsule"/>
          <body pos="0.2 0.2 0">
            <joint axis="-1 1 0" name="ankle_1" pos="0.0 0.0 0.0" range="30 70" type="hinge"/>
            <geom fromto="0.0 0.0 0.0 0.4 0.4 0.0" name="left_ankle_geom" size="0.08" type="capsule"/>
          </body>
        </body>
      </body>""".format(l1=0.2, size=0.08, l2=0.4)
        geom1 = """
      <body name="front_left_leg" pos="0 0 0">
        <geom fromto="0.0 0.0 0.0 {l1} {l1} 0.0" name="aux_1_geom" size="{size}" type="capsule"/>
        <body name="aux_1" pos="{l1} {l1} 0">
          <joint axis="0 0 1" name="hip_1" pos="0.0 0.0 0.0" range="-30 30" type="hinge"/>
          <geom fromto="0.0 0.0 0.0 {l1} {l1} 0.0" name="left_leg_geom" size="{size}" type="capsule"/>
          <body pos="{l1} {l1} 0">
            <joint axis="-1 1 0" name="ankle_1" pos="0.0 0.0 0.0" range="30 70" type="hinge"/>
            <geom fromto="0.0 0.0 0.0 {l2} {l2} 0.0" name="left_ankle_geom" size="{size}" type="capsule"/>
          </body>
        </body>
      </body>""".format(l1=0.2*random_legs_size[0], size=0.08, l2=0.4*random_legs_size[0])

        geom2_orig = """<body name="front_right_leg" pos="0 0 0">
        <geom fromto="0.0 0.0 0.0 -{l1} {l1} 0.0" name="aux_2_geom" size="{size}" type="capsule"/>
        <body name="aux_2" pos="-{l1} {l1} 0">
          <joint axis="0 0 1" name="hip_2" pos="0.0 0.0 0.0" range="-30 30" type="hinge"/>
          <geom fromto="0.0 0.0 0.0 -{l1} {l1} 0.0" name="right_leg_geom" size="{size}" type="capsule"/>
          <body pos="-{l1} {l1} 0">
            <joint axis="1 1 0" name="ankle_2" pos="0.0 0.0 0.0" range="-70 -30" type="hinge"/>
            <geom fromto="0.0 0.0 0.0 -{l2} {l2} 0.0" name="right_ankle_geom" size="{size}" type="capsule"/>
          </body>
        </body>
      </body>""".format(l1=0.2, size=0.08, l2=0.4)
        geom2 = """<body name="front_right_leg" pos="0 0 0">
          <geom fromto="0.0 0.0 0.0 -{l1} {l1} 0.0" name="aux_2_geom" size="{size}" type="capsule"/>
          <body name="aux_2" pos="-{l1} {l1} 0">
            <joint axis="0 0 1" name="hip_2" pos="0.0 0.0 0.0" range="-30 30" type="hinge"/>
            <geom fromto="0.0 0.0 0.0 -{l1} {l1} 0.0" name="right_leg_geom" size="{size}" type="capsule"/>
            <body pos="-{l1} {l1} 0">
              <joint axis="1 1 0" name="ankle_2" pos="0.0 0.0 0.0" range="-70 -30" type="hinge"/>
              <geom fromto="0.0 0.0 0.0 -{l2} {l2} 0.0" name="right_ankle_geom" size="{size}" type="capsule"/>
            </body>
          </body>
        </body>""".format(l1=0.2*random_legs_size[1], size=0.08, l2=0.4*random_legs_size[1])

        geom3_orig = """<body name="back_leg" pos="0 0 0">
        <geom fromto="0.0 0.0 0.0 -{l1} -{l1} 0.0" name="aux_3_geom" size="{size}" type="capsule"/>
        <body name="aux_3" pos="-{l1} -{l1} 0">
          <joint axis="0 0 1" name="hip_3" pos="0.0 0.0 0.0" range="-30 30" type="hinge"/>
          <geom fromto="0.0 0.0 0.0 -{l1} -{l1} 0.0" name="back_leg_geom" size="{size}" type="capsule"/>
          <body pos="-{l1} -{l1} 0">
            <joint axis="-1 1 0" name="ankle_3" pos="0.0 0.0 0.0" range="-70 -30" type="hinge"/>
            <geom fromto="0.0 0.0 0.0 -{l2} -{l2} 0.0" name="third_ankle_geom" size="{size}" type="capsule"/>
          </body>
        </body>
      </body>""".format(l1=0.2, size=0.08, l2=0.4)
        geom3 = """<body name="back_leg" pos="0 0 0">
          <geom fromto="0.0 0.0 0.0 -{l1} -{l1} 0.0" name="aux_3_geom" size="{size}" type="capsule"/>
          <body name="aux_3" pos="-{l1} -{l1} 0">
            <joint axis="0 0 1" name="hip_3" pos="0.0 0.0 0.0" range="-30 30" type="hinge"/>
            <geom fromto="0.0 0.0 0.0 -{l1} -{l1} 0.0" name="back_leg_geom" size="{size}" type="capsule"/>
            <body pos="-{l1} -{l1} 0">
              <joint axis="-1 1 0" name="ankle_3" pos="0.0 0.0 0.0" range="-70 -30" type="hinge"/>
              <geom fromto="0.0 0.0 0.0 -{l2} -{l2} 0.0" name="third_ankle_geom" size="{size}" type="capsule"/>
            </body>
          </body>
        </body>""".format(l1=0.2*random_legs_size[2], size=0.08, l2=0.4*random_legs_size[2])

        geom4_orig = """<body name="right_back_leg" pos="0 0 0">
        <geom fromto="0.0 0.0 0.0 {l1} -{l1} 0.0" name="aux_4_geom" size="{size}" type="capsule"/>
        <body name="aux_4" pos="{l1} -{l1} 0">
          <joint axis="0 0 1" name="hip_4" pos="0.0 0.0 0.0" range="-30 30" type="hinge"/>
          <geom fromto="0.0 0.0 0.0 {l1} -{l1} 0.0" name="rightback_leg_geom" size="{size}" type="capsule"/>
          <body pos="{l1} -{l1} 0">
            <joint axis="1 1 0" name="ankle_4" pos="0.0 0.0 0.0" range="30 70" type="hinge"/>
            <geom fromto="0.0 0.0 0.0 {l2} -{l2} 0.0" name="fourth_ankle_geom" size="{size}" type="capsule"/>
          </body>
        </body>
      </body>""".format(l1=0.2, size=0.08, l2=0.4)
        geom4 = """<body name="right_back_leg" pos="0 0 0">
          <geom fromto="0.0 0.0 0.0 {l1} -{l1} 0.0" name="aux_4_geom" size="{size}" type="capsule"/>
          <body name="aux_4" pos="{l1} -{l1} 0">
            <joint axis="0 0 1" name="hip_4" pos="0.0 0.0 0.0" range="-30 30" type="hinge"/>
            <geom fromto="0.0 0.0 0.0 {l1} -{l1} 0.0" name="rightback_leg_geom" size="{size}" type="capsule"/>
            <body pos="{l1} -{l1} 0">
              <joint axis="1 1 0" name="ankle_4" pos="0.0 0.0 0.0" range="30 70" type="hinge"/>
              <geom fromto="0.0 0.0 0.0 {l2} -{l2} 0.0" name="fourth_ankle_geom" size="{size}" type="capsule"/>
            </body>
          </body>
        </body>""".format(l1=0.2*random_legs_size[3], size=0.08, l2=0.4*random_legs_size[3])

        with open(path, 'r') as f:
            document = f.read()
        document = document.replace(geom1_orig, geom1)
        document = document.replace(geom2_orig, geom2)
        document = document.replace(geom3_orig, geom3)
        document = document.replace(geom4_orig, geom4)
        path = path.replace('ant', 'ant_morph')
        with open(path, 'w') as f:
            f.write(document)
        return path

    def viewer_setup(self):
        self.viewer.cam.distance = self.model.stat.extent * 0.5
