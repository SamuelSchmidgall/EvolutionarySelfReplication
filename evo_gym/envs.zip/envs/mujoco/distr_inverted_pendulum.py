import numpy as np
from gym import utils
from gym import spaces
from copy import deepcopy
from gym.envs.mujoco import mujoco_env

class DistributionalInvertedPendulumEnv(mujoco_env.MujocoEnv, utils.EzPickle):
    def __init__(self, timestep=None):
        utils.EzPickle.__init__(self)
        mujoco_env.MujocoEnv.__init__(self, 'inverted_pendulum.xml', 2)

        obs_high = np.ones(4)
        obs_low  = -1*np.ones(4)
        self.observation_space = \
            spaces.Box(low=obs_low, high=obs_high)

        self.action_space = spaces.Box(low=np.ones(1)*-1, high=np.ones(1)*1)

    def step(self, a, observation_noise=0.0, action_noise=0.0):
        reward = 0.1
        #a *= 3
        #a += action_noise*np.random.uniform(-1, 1, a.shape)

        self.do_simulation(a, self.frame_skip)
        ob = self._get_obs()
        #ob += observation_noise*np.random.normal(0, 1, ob.shape)

        notdone = np.isfinite(ob).all() and (np.abs(self.sim.data.qpos[1]) <= .2)
        done = not notdone
        return ob, reward, done, {}

    def reset_model(self):
        qpos = self.init_qpos + self.np_random.uniform(size=self.model.nq, low=-0.01, high=0.01)
        qvel = self.init_qvel + self.np_random.uniform(size=self.model.nv, low=-0.01, high=0.01)
        #qvel = np.clip(self.sim.data.qvel.flat[3:], a_min=-10, a_max=10)/10,

        self.set_state(qpos, qvel)
        return self._get_obs()

    def _get_obs(self):
        pos = deepcopy(self.sim.data.qpos)
        pos[1] /= 0.2
        return np.concatenate([pos, np.clip(self.sim.data.qvel, a_max=10, a_min=-10)/10]).ravel()

    def viewer_setup(self):
        v = self.viewer
        v.cam.trackbodyid = 0
        v.cam.distance = self.model.stat.extent
