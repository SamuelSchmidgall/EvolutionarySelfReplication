import numpy as np
from gym import utils
from gym.envs.mujoco import mujoco_env

class Ant4DDynamicEnv(mujoco_env.MujocoEnv, utils.EzPickle):
    def __init__(self):
        self.iteration = 0
        self.mod_direction_change = 125
        self.direction = np.random.choice([-1, 1], p=[0.5, 0.5], size=(2,))
        mujoco_env.MujocoEnv.__init__(self, 'ant.xml', 5)
        utils.EzPickle.__init__(self)

    def step(self, a):
        self.iteration += 1
        if self.iteration%self.mod_direction_change == 0:
            self.direction = np.random.choice([-1, 1], p=[0.5, 0.5], size=(2,))
        xposbefore = self.get_body_com("torso")[0]
        yposbefore = self.get_body_com("torso")[1]
        self.do_simulation(a, self.frame_skip)
        xposafter = self.get_body_com("torso")[0]
        yposafter = self.get_body_com("torso")[1]
        forward_reward = self.direction[0]*(xposafter - xposbefore)/self.dt
        side_reward = self.direction[1]*(yposafter - yposbefore)/self.dt
        reward = forward_reward + side_reward
        state = self.state_vector()
        notdone = np.isfinite(state).all()
        done = not notdone
        ob = self._get_obs()
        return ob, reward, done, dict(
            reward_forward=forward_reward,
            reward_side=side_reward,
            direction=self.direction
        )

    def _get_obs(self):
        return np.concatenate([
            self.sim.data.qpos.flat[2:],
            self.sim.data.qvel.flat,
            self.direction,
            #np.clip(self.sim.data.cfrc_ext, -1, 1).flat,
        ])

    def alive_bonus(self, z, pitch):
        return +1 if z > 0.26 else -1  # 0.25 is central sphere rad, die if it scrapes the ground

    def reset_model(self):
        self.iteration = 0
        self.direction = np.random.choice([-1, 1], p=[0.5, 0.5], size=(2,))
        qpos = self.init_qpos + self.np_random.uniform(size=self.model.nq, low=-.1, high=.1)
        qvel = self.init_qvel + self.np_random.randn(self.model.nv) * .1
        self.set_state(qpos, qvel)
        return self._get_obs()

    def viewer_setup(self):
        self.viewer.cam.distance = self.model.stat.extent * 0.5
