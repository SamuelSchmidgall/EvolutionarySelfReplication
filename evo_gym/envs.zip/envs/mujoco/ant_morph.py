import numpy as np
from gym import utils
from gym.envs.mujoco import mujoco_env

class AntMorphEnv(mujoco_env.MujocoEnv, utils.EzPickle):
    def __init__(self, worker_id=0, morphology=None):
        self.iteration = 0
        self.pos_time = 250
        self.worker_id = worker_id
        self.morphology = morphology
        #if self.morphology is None:
        #    self.morphology = \
        #        np.random.normal(loc=0.0, scale=0.3, size=(12,))
        #self.morphology += 1.0
        #self.randomize_antmorph(self.morphology, worker_id=worker_id)
        #self.change_morphology()
        mujoco_env.MujocoEnv.__init__(self, 'ant.xml', 5)
        utils.EzPickle.__init__(self)

    def step(self, a):
        self.iteration += 1
        if self.iteration%self.pos_time == 0:
            #qpos = self.data.qpos
            #qpos[0:2] = 0 #np.random.randint(-10, 10)
            #self.set_state(qpos, self.data.qvel)
            self.set_state(
                self.init_qpos + np.random.uniform(low=-.1, high=.1, size=self.model.nq),
                self.init_qvel + np.random.uniform(low=-.1, high=.1, size=self.model.nv)
            )
        #xposbefore = self.get_body_com("torso")[0]
        self.do_simulation(a, self.frame_skip)
        #xposafter = self.get_body_com("torso")[0]
        #forward_reward = (xposafter - xposbefore)/self.dt
        ctrl_cost = .5 * np.square(a).sum()
        #contact_cost = 0.5 * 1e-3 * np.sum(
        #    np.square(np.clip(self.sim.data.cfrc_ext, -1, 1)))
        #survive_reward = 1.0
        #reward = self.data.body_xvelp[1][0]#forward_reward - ctrl_cost - contact_cost + survive_reward
        reward = np.sqrt(self.data.qvel[0] ** 2 + self.data.qvel[1] ** 2) - ctrl_cost * 0.5 * 1e-3
        state = self.state_vector()
        notdone = np.isfinite(state).all() #and self.data.body_xpos[1][2] > 0.3
            #and state[2] >= 0.2 and state[2] <= 1.0
        done = not notdone
        ob = self._get_obs()
        return ob, reward, done, dict()

    def change_morphology(self):
        morphology = np.random.normal(loc=0.0, scale=0.05, size=(12,))
        self.randomize_antmorph(morphology, self.worker_id)
        mujoco_env.MujocoEnv.__init__(self, 'ant_morph{}.xml'.format(self.worker_id), 5)
        self.set_state(
            self.init_qpos + np.random.uniform(low=-.1, high=.1, size=self.model.nq),
            self.init_qvel + np.random.uniform(low=-.1, high=.1, size=self.model.nv)
        )

    def _get_obs(self):
        quat = np.array(
            [self.data.body_xquat[1][0], self.data.body_xquat[1][3]])
        return np.concatenate([
            quat,
            #self.sim.data.qpos.flat[2:],
            self.sim.data.qpos.flat[:2],
            self.sim.data.qvel.flat,
            self.data.ctrl,
            #self.target_pos - self.sim.data.qpos.flat[:2]
            #np.clip(self.sim.data.cfrc_ext, -1, 1).flat,
        ])


    def alive_bonus(self, z, pitch):
        return +1 if z > 0.26 else -1  # 0.25 is central sphere rad, die if it scrapes the ground

    def reset_model(self):
        #random_legs_size = np.random.uniform(low=0.7, high=1.3, size=(4,))
        #self.randomize_antmorph(self.morphology, self.worker_id)
        self.change_morphology()
        mujoco_env.MujocoEnv.__init__(self, 'ant_morph.xml', 5)
        qpos = self.init_qpos + self.np_random.uniform(size=self.model.nq, low=-.1, high=.1)
        qvel = self.init_qvel + self.np_random.randn(self.model.nv) * .1
        self.set_state(qpos, qvel)
        return self._get_obs()

    def randomize_antmorph(self, random_legs_size, worker_id):

        path = "/home/sam/PycharmProjects/virtual_envs/spiking/lib/python3.6/site-packages/gym/gym/envs/mujoco/assets/ant.xml"
        geom1_orig = """
      <body name="front_left_leg" pos="0 0 0">
        <geom fromto="0.0 0.0 0.0 0.2 0.2 0.0" name="aux_1_geom" size="0.08" type="capsule"/>
        <body name="aux_1" pos="0.2 0.2 0">
          <joint axis="0 0 1" name="hip_1" pos="0.0 0.0 0.0" range="-30 30" type="hinge"/>
          <geom fromto="0.0 0.0 0.0 0.2 0.2 0.0" name="left_leg_geom" size="0.08" type="capsule"/>
          <body pos="0.2 0.2 0">
            <joint axis="-1 1 0" name="ankle_1" pos="0.0 0.0 0.0" range="30 70" type="hinge"/>
            <geom fromto="0.0 0.0 0.0 0.4 0.4 0.0" name="left_ankle_geom" size="0.08" type="capsule"/>
          </body>
        </body>
      </body>""".format(l1=0.2, size=0.08, l2=0.4)
        geom1 = """
      <body name="front_left_leg" pos="0 0 0">
        <geom fromto="0.0 0.0 0.0 {l1} {l1} 0.0" name="aux_1_geom" size="{size}" type="capsule"/>
        <body name="aux_1" pos="{l1} {l1} 0">
          <joint axis="0 0 1" name="hip_1" pos="0.0 0.0 0.0" range="-30 30" type="hinge"/>
          <geom fromto="0.0 0.0 0.0 {l1} {l1} 0.0" name="left_leg_geom" size="{size}" type="capsule"/>
          <body pos="{l1} {l1} 0">
            <joint axis="-1 1 0" name="ankle_1" pos="0.0 0.0 0.0" range="30 70" type="hinge"/>
            <geom fromto="0.0 0.0 0.0 {l2} {l2} 0.0" name="left_ankle_geom" size="{size}" type="capsule"/>
          </body>
        </body>
      </body>""".format(l1=0.2*(1+random_legs_size[0]), size=0.08*(1+random_legs_size[8]), l2=0.4*(1+random_legs_size[1]))

        geom2_orig = """<body name="front_right_leg" pos="0 0 0">
        <geom fromto="0.0 0.0 0.0 -{l1} {l1} 0.0" name="aux_2_geom" size="{size}" type="capsule"/>
        <body name="aux_2" pos="-{l1} {l1} 0">
          <joint axis="0 0 1" name="hip_2" pos="0.0 0.0 0.0" range="-30 30" type="hinge"/>
          <geom fromto="0.0 0.0 0.0 -{l1} {l1} 0.0" name="right_leg_geom" size="{size}" type="capsule"/>
          <body pos="-{l1} {l1} 0">
            <joint axis="1 1 0" name="ankle_2" pos="0.0 0.0 0.0" range="-70 -30" type="hinge"/>
            <geom fromto="0.0 0.0 0.0 -{l2} {l2} 0.0" name="right_ankle_geom" size="{size}" type="capsule"/>
          </body>
        </body>
      </body>""".format(l1=0.2, size=0.08, l2=0.4)
        geom2 = """<body name="front_right_leg" pos="0 0 0">
          <geom fromto="0.0 0.0 0.0 -{l1} {l1} 0.0" name="aux_2_geom" size="{size}" type="capsule"/>
          <body name="aux_2" pos="-{l1} {l1} 0">
            <joint axis="0 0 1" name="hip_2" pos="0.0 0.0 0.0" range="-30 30" type="hinge"/>
            <geom fromto="0.0 0.0 0.0 -{l1} {l1} 0.0" name="right_leg_geom" size="{size}" type="capsule"/>
            <body pos="-{l1} {l1} 0">
              <joint axis="1 1 0" name="ankle_2" pos="0.0 0.0 0.0" range="-70 -30" type="hinge"/>
              <geom fromto="0.0 0.0 0.0 -{l2} {l2} 0.0" name="right_ankle_geom" size="{size}" type="capsule"/>
            </body>
          </body>
        </body>""".format(l1=0.2*(1+random_legs_size[2]), size=0.08*(1+random_legs_size[9]), l2=0.4*(1+random_legs_size[3]))

        geom3_orig = """<body name="back_leg" pos="0 0 0">
        <geom fromto="0.0 0.0 0.0 -{l1} -{l1} 0.0" name="aux_3_geom" size="{size}" type="capsule"/>
        <body name="aux_3" pos="-{l1} -{l1} 0">
          <joint axis="0 0 1" name="hip_3" pos="0.0 0.0 0.0" range="-30 30" type="hinge"/>
          <geom fromto="0.0 0.0 0.0 -{l1} -{l1} 0.0" name="back_leg_geom" size="{size}" type="capsule"/>
          <body pos="-{l1} -{l1} 0">
            <joint axis="-1 1 0" name="ankle_3" pos="0.0 0.0 0.0" range="-70 -30" type="hinge"/>
            <geom fromto="0.0 0.0 0.0 -{l2} -{l2} 0.0" name="third_ankle_geom" size="{size}" type="capsule"/>
          </body>
        </body>
      </body>""".format(l1=0.2, size=0.08, l2=0.4)
        geom3 = """<body name="back_leg" pos="0 0 0">
          <geom fromto="0.0 0.0 0.0 -{l1} -{l1} 0.0" name="aux_3_geom" size="{size}" type="capsule"/>
          <body name="aux_3" pos="-{l1} -{l1} 0">
            <joint axis="0 0 1" name="hip_3" pos="0.0 0.0 0.0" range="-30 30" type="hinge"/>
            <geom fromto="0.0 0.0 0.0 -{l1} -{l1} 0.0" name="back_leg_geom" size="{size}" type="capsule"/>
            <body pos="-{l1} -{l1} 0">
              <joint axis="-1 1 0" name="ankle_3" pos="0.0 0.0 0.0" range="-70 -30" type="hinge"/>
              <geom fromto="0.0 0.0 0.0 -{l2} -{l2} 0.0" name="third_ankle_geom" size="{size}" type="capsule"/>
            </body>
          </body>
        </body>""".format(l1=0.2*(1+random_legs_size[4]), size=0.08*(1+random_legs_size[10]), l2=0.4*(1+random_legs_size[5]))

        geom4_orig = """<body name="right_back_leg" pos="0 0 0">
        <geom fromto="0.0 0.0 0.0 {l1} -{l1} 0.0" name="aux_4_geom" size="{size}" type="capsule"/>
        <body name="aux_4" pos="{l1} -{l1} 0">
          <joint axis="0 0 1" name="hip_4" pos="0.0 0.0 0.0" range="-30 30" type="hinge"/>
          <geom fromto="0.0 0.0 0.0 {l1} -{l1} 0.0" name="rightback_leg_geom" size="{size}" type="capsule"/>
          <body pos="{l1} -{l1} 0">
            <joint axis="1 1 0" name="ankle_4" pos="0.0 0.0 0.0" range="30 70" type="hinge"/>
            <geom fromto="0.0 0.0 0.0 {l2} -{l2} 0.0" name="fourth_ankle_geom" size="{size}" type="capsule"/>
          </body>
        </body>
      </body>""".format(l1=0.2, size=0.08, l2=0.4)
        geom4 = """<body name="right_back_leg" pos="0 0 0">
          <geom fromto="0.0 0.0 0.0 {l1} -{l1} 0.0" name="aux_4_geom" size="{size}" type="capsule"/>
          <body name="aux_4" pos="{l1} -{l1} 0">
            <joint axis="0 0 1" name="hip_4" pos="0.0 0.0 0.0" range="-30 30" type="hinge"/>
            <geom fromto="0.0 0.0 0.0 {l1} -{l1} 0.0" name="rightback_leg_geom" size="{size}" type="capsule"/>
            <body pos="{l1} -{l1} 0">
              <joint axis="1 1 0" name="ankle_4" pos="0.0 0.0 0.0" range="30 70" type="hinge"/>
              <geom fromto="0.0 0.0 0.0 {l2} -{l2} 0.0" name="fourth_ankle_geom" size="{size}" type="capsule"/>
            </body>
          </body>
        </body>""".format(l1=0.2*(1+random_legs_size[6]), size=0.08*(1+random_legs_size[11]), l2=0.4*(1+random_legs_size[7]))

        with open(path, 'r') as f:
            document = f.read()
        document = document.replace(geom1_orig, geom1)
        document = document.replace(geom2_orig, geom2)
        document = document.replace(geom3_orig, geom3)
        document = document.replace(geom4_orig, geom4)
        path = path.replace('ant', 'ant_morph{}'.format(worker_id))
        with open(path, 'w') as f:
            f.write(document)
        return path

    def viewer_setup(self):
        self.viewer.cam.distance = self.model.stat.extent * 0.5
