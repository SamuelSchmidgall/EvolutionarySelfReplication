import numpy as np
from gym import utils
from gym.envs.mujoco import mujoco_env

class AntModEnv(mujoco_env.MujocoEnv, utils.EzPickle):
    def __init__(self):
        self.itr = 0
        self.prev_fw_r = 0
        self.prev_fw_r1 = 0
        self.j_range_lower = [-100 for _k in range(9)]
        self.j_range_upper = [ 100 for _k in range(9)]
        self.joints = [0, 1, 2, 3, None]
        self.joint_fail_probs = np.array([0.25, 0.25, 0.25, 0.25, 0.0])
        self.failed_joint = np.random.choice(self.joints, p=self.joint_fail_probs)
        mujoco_env.MujocoEnv.__init__(self, 'ant.xml', 5)
        utils.EzPickle.__init__(self)
        self.j_range_lower = [_[0] for _ in self.model.jnt_range]
        self.j_range_upper = [_[1] for _ in self.model.jnt_range]

    def step(self, a):
        if self.failed_joint is not None:
            a[self.failed_joint*2:(self.failed_joint+1)*2] = 0.0
        xposbefore = self.get_body_com("torso")[0]
        self.do_simulation(a, self.frame_skip)
        xposafter = self.get_body_com("torso")[0]
        forward_reward = (xposafter - xposbefore)#/self.dt
        #ctrl_cost = .5 * np.square(a).sum()
        #contact_cost = 0.5 * 1e-3 * np.sum(
        #    np.square(np.clip(self.sim.data.cfrc_ext, -1, 1)))
        #survive_reward = 1.0
        #reward = (self.data.body_xvelp[1][0]**2)*\
        #         np.sign(self.data.body_xvelp[1][0]) - 0.005*ctrl_cost + 0.01 + contact_cost
        jpos = self.data.qpos[self.model.jnt_qposadr]
        jpos_le = np.where(jpos <= self.j_range_lower, 1, 0)
        jpos_ge = np.where(jpos >= self.j_range_upper, 1, 0)
        joint_max_loss = sum(jpos_ge + jpos_le)
        reward = 50*forward_reward + 1.0 - 0.1*joint_max_loss# - contact_cost


        state = self.state_vector()
        notdone = np.isfinite(state).all() and \
            not (self.data.body_xpos[1][2] <= 0.3) and 0.2 <= state[2] <= 1.0
        done = not notdone #or (forward_reward < 0.01 and self.prev_fw_r < 0.01 and self.prev_fw_r1 < 0.01 and self.itr > 35)
        ob = self._get_obs()
        self.itr += 1
        self.prev_fw_r1 = self.prev_fw_r
        self.prev_fw_r = forward_reward
        return ob, reward, done, dict(
            #reward_forward=forward_reward,
            #reward_ctrl=-ctrl_cost,
            #reward_contact=-contact_cost,
            #reward_survive=survive_reward
        )

    def _get_obs(self):
        state = self.state_vector()
        return np.concatenate([
            self.sim.data.qpos.flat[1:],
            self.sim.data.qvel.flat,
            np.array([self.data.body_xpos[1][2], abs(state[2] - 0.2), abs(state[2] - 1.0)])
            #np.clip(self.sim.data.cfrc_ext, -1, 1).flat,
        ])

    def reset_model(self):
        self.itr = 0
        self.prev_fw_r = 0
        self.failed_joint = np.random.choice(self.joints, p=self.joint_fail_probs)
        qpos = self.init_qpos + self.np_random.uniform(size=self.model.nq, low=-.1, high=.1)
        qvel = self.init_qvel + self.np_random.randn(self.model.nv) * .1
        self.set_state(qpos, qvel)
        return self._get_obs()

    def viewer_setup(self):
        self.viewer.cam.distance = self.model.stat.extent * 0.5
