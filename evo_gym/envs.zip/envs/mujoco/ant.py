import numpy as np
from gym import utils
from gym.envs.mujoco import mujoco_env

class AntEnv(mujoco_env.MujocoEnv, utils.EzPickle):
    def __init__(self):
        self.iteration = 0
        self.pos_time = 500
        mujoco_env.MujocoEnv.__init__(self, 'ant_rang.xml', 5)
        utils.EzPickle.__init__(self)

    def step(self, a):
        a = np.clip(a, a_min=-1, a_max=1)
        if self.iteration%self.pos_time == 0:
            #qpos = self.data.qpos
            #qpos[0:2] = 0 #np.random.randint(-10, 10)
            #self.set_state(qpos, self.data.qvel)
            self.set_state(
                self.init_qpos + np.random.uniform(low=-.1, high=.1, size=self.model.nq),
                self.init_qvel + np.random.uniform(low=-.1, high=.1, size=self.model.nv)
            )

        self.iteration += 1
        xposbefore = self.get_body_com("torso")[0]
        self.do_simulation(a, self.frame_skip)
        xposafter = self.get_body_com("torso")[0]
        #forward_reward = (xposafter - xposbefore)/self.dt
        #ctrl_cost = .5 * np.square(a).sum()
        #contact_cost = 0.5 * 1e-3 * np.sum(
        #    np.square(np.clip(self.sim.data.cfrc_ext, -1, 1)))
        #survive_reward = 1.0
        reward = np.sqrt(self.data.qvel[0]**2 + self.data.qvel[1]**2) #- ctrl_cost*0.01# - contact_cost + survive_reward
        #elif self.curriculum == 1:
        #    reward = forward_reward #np.sqrt(self.data.qvel[0]**2 + self.data.qvel[1]**2)
        #elif self.curriculum > 1:
        #    reward = -forward_reward
        #self.data.body_xvelp[1][0]#forward_reward - ctrl_cost - contact_cost + survive_reward
        #reward += -sum(abs(self.target_pos - self.data.qpos[:2]))
        #reward += sum(abs(self.average_pos - self.data.qpos[:2]))
        state = self.state_vector()
        notdone = np.isfinite(state).all() #and self.data.body_xpos[1][2] > 0.3
            #and state[2] >= 0.2 and state[2] <= 1.0
        #self.average_pos_list = self.average_pos_list[1:] + [self.data.qpos[:2]]
        #self.average_pos = np.average(np.array(self.average_pos_list))
        done = not notdone
        ob = self._get_obs()
        return ob, reward, done, dict(
            #reward_forward=forward_reward,
            #reward_ctrl=-ctrl_cost,
            #reward_contact=-contact_cost,
            #reward_survive=survive_reward
        )

    def _get_obs(self):
        quat = np.array(
            [self.data.body_xquat[1][0], self.data.body_xquat[1][3]])
        return np.concatenate([
            quat,
            #self.sim.data.qpos.flat[2:],
            self.sim.data.qpos.flat[:2],
            self.sim.data.qvel.flat,
            self.data.ctrl,
            #self.target_pos - self.sim.data.qpos.flat[:2]
            #np.clip(self.sim.data.cfrc_ext, -1, 1).flat,
        ])

    #def alive_bonus(self, z, pitch):
    #    return +1 if z > 0.26 else -1  # 0.25 is central sphere rad, die if it scrapes the ground

    def reset_model(self):
        #self.average_pos_list = [np.zeros((2,)) for _k in range(self.avg_pos_sz)]
        #self.average_pos = np.average(np.array(self.average_pos_list))
        qpos = self.init_qpos + self.np_random.uniform(size=self.model.nq, low=-.1, high=.1)
        qvel = self.init_qvel + self.np_random.randn(self.model.nv) * .1
        self.set_state(qpos, qvel)
        return self._get_obs()

    def viewer_setup(self):
        self.viewer.cam.distance = self.model.stat.extent * 0.5
