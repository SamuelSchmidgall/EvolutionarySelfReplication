import os
import numpy as np
from gym import utils
from gym import spaces
from gym.envs.mujoco import mujoco_env

class CueAssociationEnv(mujoco_env.MujocoEnv, utils.EzPickle):
    def __init__(self, timestep=None):
        # num unique inputs
        self.BS = 1
        self.ni = 2
        # cue size
        self.cu = 10
        self.ADDINPUT = 4
        outputsize = 2
        self.eplen = 100
        self.itr = 0
        self.NBINPUTBITS = self.cu + 1
        self.input_size = self.NBINPUTBITS +  outputsize + self.ADDINPUT
        obs_high = np.ones(3)
        obs_low  = 0.0*np.ones(3)
        self.action_space = [0.0, 1.0]
        self.observation_space = spaces.Box(low=obs_low, high=obs_high)

        mujoco_env.MujocoEnv.__init__(self, 'hopper.xml', 4)
        utils.EzPickle.__init__(self)
        self.observation_space = spaces.Box(low=obs_low, high=obs_high)

    def step(self, action):
        done = self.itr >= self.eplen
        self.itr += 1
        ob = self._get_obs()
        reward = self.get_reward()
        return ob, reward, done, dict()

    def _get_obs(self):
        return np.zeros(17)

    def get_reward(self):
        return 0.0

    def reset_model(self,):
        self.itr = 0

        cuedata = []
        for nb in range(self.BS):
            cuedata.append([])
            for ncue in range(self.ni):
                assert len(cuedata[nb]) == ncue
                foundsame = 1
                cpt = 0
                while foundsame > 0:
                    cpt += 1
                    if cpt > 10000:
                        # This should only occur with very weird parameters, e.g. cs=2, ni>4
                        raise ValueError("Could not generate a full list of different cues")
                    foundsame = 0
                    candidate = np.random.randint(2, size=self.cu) * 2 - 1
                    for backtrace in range(ncue):
                        if np.array_equal(cuedata[nb][backtrace], candidate):
                            foundsame = 1

                cuedata[nb].append(candidate)

        cues = []
        reward = np.zeros(self.BS)
        for nb in range(self.BS):
            cues.append([])
        dist = 0
        numactionschosen = np.zeros(self.BS, dtype='int32')

        nbtrials = np.zeros(self.BS)
        nbrewardabletrials = np.zeros(self.BS)
        thistrialhascorrectcue = np.zeros(self.BS)
        triallength = np.zeros(self.BS, dtype='int32')
        correctcue = np.random.randint(self.ni, size=self.BS)

        trialstep = np.zeros(self.BS, dtype='int32')

        # if params['clamp'] == 0:
        inputs = np.zeros((self.BS, self.input_size), dtype='float32')
        # else:
        #    inputs = np.zeros((1, params['hs']), dtype='float32')
        import random
        for nb in range(self.BS):
            if trialstep[nb] == 0:
                thistrialhascorrectcue[nb] = 0
                # Trial length is randomly modulated for each trial; first time step always -1 (i.e. no input cue), last time step always response-cue (i.e. NBINPUTBITS-1).
                # triallength = self.ni // 2  + 3 + np.random.randint(1 + self.ni)  # 3 fixed-cue time steps (1st, last and next-to-last) + some random nb of no-cue time steps
                triallength[nb] = self.ni // 2 + 3 + np.random.randint(self.ni)  # 3 fixed-cue time steps (1st, last and next-to-last) + some random nb of no-cue time steps
                # In any trial, we only show half the cues (randomly chosen), once each:
                mycues = [x for x in range(self.ni)]
                random.shuffle(mycues)
                mycues = mycues[:len(mycues) // 2]
                # The rest is filled with no-input time steps (i.e. cue = -1), but also with the 3 fixed-cue steps (1st, last, next-to-last)
                for nc in range(triallength[nb] - 3 - len(mycues)):
                    mycues.append(-1)
                random.shuffle(mycues)
                mycues.insert(0, -1)
                mycues.append(self.ni)
                mycues.append(
                    -1)  # The first and last time step have no input (cue -1), the next-to-last has the response cue.
                assert (len(mycues) == triallength[nb])
                cues[nb] = mycues

            inputs[nb, :self.NBINPUTBITS] = 0
            if cues[nb][trialstep[nb]] > -1 and cues[nb][trialstep[nb]] < self.ni:
                # inputs[0, cues[trialstep]] = 1.0
                inputs[nb, :self.NBINPUTBITS - 1] = cuedata[nb][cues[nb][trialstep[nb]]][:]
                if cues[nb][trialstep[nb]] == correctcue[nb]:
                    thistrialhascorrectcue[nb] = 1
            if cues[nb][trialstep[nb]] == self.ni:
                inputs[nb, self.NBINPUTBITS - 1] = 1  # "Go" cue

            inputs[nb, self.NBINPUTBITS + 0] = 1.0  # Bias neuron, probably not necessary
            inputs[nb, self.NBINPUTBITS + 1] = self.itr / self.eplen
            inputs[nb, self.NBINPUTBITS + 2] = 1.0 * reward[nb]  # Reward from previous time step
            if self.itr > 0:
                inputs[nb, self.NBINPUTBITS + self.ADDINPUT + numactionschosen[nb]] = 1  # Previously chosen action
        #import torch
        #inputsC = torch.from_numpy(inputs).cuda()
        return inputs[0]


    def viewer_setup(self):
        return None
