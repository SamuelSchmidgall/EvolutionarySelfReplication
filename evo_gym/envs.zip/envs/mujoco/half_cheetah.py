import os
import numpy as np
from gym import utils
from gym import spaces
from gym.envs.mujoco import mujoco_env

class HalfCheetahEnv(mujoco_env.MujocoEnv, utils.EzPickle):
    def __init__(self, timestep=None, torso_density_noise=None,
                 joint_noise=None, action_power_noise_multiplier_std=None):
        model_path = 'half_cheetah.xml'

        self.action_mult = 1 if action_power_noise_multiplier_std \
            is None else np.random.normal(loc=1.0, scale=action_power_noise_multiplier_std)

        if torso_density_noise is not None:
            if model_path.startswith("/"):
                fullpath = model_path
            else:
                fullpath = os.path.join(os.path.dirname(__file__), "assets", model_path)
            model_path = self.generate_new_joint_model(fullpath, torso_density_noise)

        if joint_noise is not None:
            if model_path.startswith("/"):
                fullpath = model_path
            else:
                fullpath = os.path.join(os.path.dirname(__file__), "assets", model_path)
            model_path = self.generate_new_joint_model(fullpath, joint_noise)

        mujoco_env.MujocoEnv.__init__(self, model_path, 5)
        utils.EzPickle.__init__(self)
        obs_high = np.ones(12)
        obs_low  = -1*np.ones(12)
        self.observation_space = spaces.Box(low=obs_low, high=obs_high)

    def step(self, action):
        action *= self.action_mult

        xposbefore = self.sim.data.qpos[0]
        self.do_simulation(action, self.frame_skip)
        xposafter = self.sim.data.qpos[0]
        ob = self._get_obs()
        reward_ctrl = - 0.1 * np.square(action).sum()
        reward_run = (xposafter - xposbefore)/self.dt
        reward = reward_ctrl + reward_run
        done = False
        return ob, reward, done, dict(reward_run=reward_run, reward_ctrl=reward_ctrl)

    def _get_obs(self):
        joint_range = self.model.jnt_range[3:]
        joint_divisor = np.array([_j[1] - _j[0] for _j in joint_range])/1.5
        return np.concatenate([
            np.clip((self.sim.data.qpos.flat[3:])/joint_divisor, a_max=1, a_min=-1),
            np.clip(self.sim.data.qvel.flat[3:], a_min=-10, a_max=10)/10,
        ])

    def reset_model(self, torso_density=None, joint_noise=None):
        qpos = self.init_qpos + self.np_random.uniform(low=-.1, high=.1, size=self.model.nq)
        qvel = self.init_qvel + self.np_random.randn(self.model.nv) * .1
        self.set_state(qpos, qvel)
        return self._get_obs()

    def viewer_setup(self):
        self.viewer.cam.distance = self.model.stat.extent * 0.5

    def generate_new_joint_model(self, path, friction):
        original_damping = np.array([0, 0, 0, 6, 4.5, 3, 4.5, 3, 1.5])
        noise = np.random.normal(loc=0.0, scale=friction*original_damping)
        friction = original_damping + noise
        with open(path, 'r') as f:
            document = f.read()
        document = document.replace('<joint armature="0" axis="1 0 0" damping="0" limited="false" name="rootx" pos="0 0 0" stiffness="0" type="slide"/>',
            '<joint armature="0" axis="1 0 0" damping="{}" limited="false" name="rootx" pos="0 0 0" stiffness="0" type="slide"/>'.format(friction[0]))
        document = document.replace('<joint armature="0" axis="0 0 1" damping="0" limited="false" name="rootz" pos="0 0 0" stiffness="0" type="slide"/>',
            '<joint armature="0" axis="0 0 1" damping="{}" limited="false" name="rootz" pos="0 0 0" stiffness="0" type="slide"/>'.format(friction[1]))
        document = document.replace('<joint armature="0" axis="0 1 0" damping="0" limited="false" name="rooty" pos="0 0 0" stiffness="0" type="hinge"/>',
            '<joint armature="0" axis="0 1 0" damping="{}" limited="false" name="rooty" pos="0 0 0" stiffness="0" type="hinge"/>'.format(friction[2]))
        document = document.replace('<joint axis="0 1 0" damping="6" name="bthigh" pos="0 0 0" range="-.52 1.05" stiffness="240" type="hinge"/>',
            '<joint axis="0 1 0" damping="{}" name="bthigh" pos="0 0 0" range="-.52 1.05" stiffness="240" type="hinge"/>'.format(friction[3]))
        document = document.replace('damping="4.5" name="bshin"', 'damping="{}" name="bshin"'.format(friction[4]))
        document = document.replace('<joint axis="0 1 0" damping="3" name="bfoot" pos="0 0 0" range="-.4 .785" stiffness="120" type="hinge"/>' ,
            '<joint axis="0 1 0" damping="{}" name="bfoot" pos="0 0 0" range="-.4 .785" stiffness="120" type="hinge"/>'.format(friction[5]))
        document = document.replace(
            """<joint axis="0 1 0" damping="4.5" name="fthigh" pos="0 0 0" range="-1 .7" stiffness="180" type="hinge"/>""",
            """<joint axis="0 1 0" damping="{}" name="fthigh" pos="0 0 0" range="-1 .7" stiffness="180" type="hinge"/>""".format(friction[6]))
        document = document.replace(
            """<joint axis="0 1 0" damping="3" name="fshin" pos="0 0 0" range="-1.2 .87" stiffness="120" type="hinge"/>""",
            """<joint axis="0 1 0" damping="{}" name="fshin" pos="0 0 0" range="-1.2 .87" stiffness="120" type="hinge"/>""".format(friction[7]))
        document = document.replace(
            """<joint axis="0 1 0" damping="1.5" name="ffoot" pos="0 0 0" range="-.5 .5" stiffness="60" type="hinge"/>""",
            """<joint axis="0 1 0" damping="{}" name="ffoot" pos="0 0 0" range="-.5 .5" stiffness="60" type="hinge"/>""".format(friction[8]) )
        path = path.replace('half_cheetah', 'half_cheetah_MOD')
        with open(path, 'w') as f:
            f.write(document)
        return path

    def generate_new_torso_model(self, path, torso):
        with open(path, 'r') as f:
            document = f.read()
        document = document.replace('body name="torso" pos="0 0 .7"', 'body name="torso" pos="0 0 .7" density="{}"'.format(torso))
        path = path.replace('half_cheetah', 'half_cheetah_MOD')
        with open(path, 'w') as f:
            f.write(document)
        return path