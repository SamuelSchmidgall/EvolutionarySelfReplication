import os
import math
import mujoco_py
import numpy as np
from gym import utils
from gym import spaces
from copy import deepcopy
from gym.envs.mujoco import mujoco_env
import cmath

def calculate_upright_angle(alpha):
    a = alpha % (2 * np.pi) + -np.pi
    return a

def calc_pi_wrap_diff(angle1,angle2):
    dx = angle1 - angle2
    if abs(dx)> math.pi:
        if np.sign(dx)==-1:
            dx = dx-2*math.pi
        else:
            dx = dx+2*math.pi
    return dx

class FilteredDerivative:
    def __init__(self,Ts,zeta,wn):
        # Computing coefficients (documentation to come)
        a = cmath.sqrt(zeta**2 - 1)
        A = (cmath.exp(-Ts*wn*(zeta - a)) - cmath.exp(-Ts*wn*(zeta + a)))/a
        self.K1 = 0.5*wn*A.real
        self.K2 = -self.K1
        K3 = cmath.exp(-Ts*wn*(zeta - a))  + cmath.exp(-Ts*wn*(zeta + a))
        self.K3 = K3.real
        self.K4 = -math.exp(-2*Ts*wn*zeta)
        # Initializing filter states
        self.pos_prevprev = 0
        self.pos_prev = 0
        self.vel_prevprev = 0
        self.vel_prev = 0

    def reset(self):
        # resetting filter states
        self.pos_prevprev = 0
        self.pos_prev = 0
        self.vel_prevprev = 0
        self.vel_prev = 0

    def step(self,pos):
        vel = self.K1*self.pos_prev + self.K2*self.pos_prevprev \
                + self.K3*self.vel_prev + self.K4*self.vel_prevprev
        self.pos_prevprev = self.pos_prev
        self.pos_prev = pos
        self.vel_prevprev = self.vel_prev
        self.vel_prev = vel
        return vel

class QuanserPendulumBalanceEnv(mujoco_env.MujocoEnv, utils.EzPickle):
    def __init__(self, timestep=None):
        self.prev_r = 0
        self.forces = 0
        self.act_diff = 0
        self.timestep = 0
        self.prev_time = 0
        self.prev_action = 0
        self.theta_state = 0
        self.alpha_state = 0
        self.prev_upright = 0
        self.random_scalar = 1
        self.unique_id = np.random.randint(0, 99999)
        self.prev_theta = np.zeros(2)

        model_path = 'quanser_pendulum_single.xml'
        if timestep is not None:
            if model_path.startswith("/"):
                fullpath = model_path
            else:
                fullpath = os.path.join(os.path.dirname(__file__), "assets", model_path)

            model_path = self.generate_new_ts_model(fullpath, timestep)

        mujoco_env.MujocoEnv.__init__(self, model_path, 1)
        utils.EzPickle.__init__(self)

        # Initializing filtered derivative filters
        wn = 250
        zeta = 0.3
        Ts = self.model.opt.timestep
        self.thetaFilter = FilteredDerivative(Ts,zeta,wn)
        self.alphaFilter = FilteredDerivative(Ts,zeta,wn)

        self.action_space = spaces.Box(low=-1*np.ones(1), high=np.ones(1))

        obs_high = np.array([ 1,  1,  1,  1,  1])
        obs_low  = np.array([-1, -1, -1, -1, -1])
        self.observation_space = spaces.Box(low=obs_low, high=obs_high)

        self.set_state(
            np.array([0.0, 0.0]),
            np.array([0.0, 0.0])
        )


    def step(self, action):
        try:
            self.alpha_state = self.alpha_state
        except Exception:
            self.prev_r = 0.0
            self.timestep = 0
            self.prev_time = 0
            self.theta_state = 0
            self.alpha_state = 0
            self.prev_theta = np.zeros(2)
            self.base_timestep = self.model.opt.timestep
        try:
            self.thetaFilter=self.thetaFilter
        except Exception:
            # Initializing filtered derivative filters if not done already
            wn = 250
            zeta = 0.3
            Ts = self.model.opt.timestep
            self.thetaFilter = FilteredDerivative(Ts,zeta,wn)
            self.alphaFilter = FilteredDerivative(Ts,zeta,wn)

        K_T = 0.0077
        multiplier = 3*8
        voltage_in = np.clip(action, a_min=-8, a_max=8) * multiplier
        torque = K_T * voltage_in

        self.prev_theta = deepcopy(self.data.qpos)
        self.do_simulation(torque, self.frame_skip)

        self.timestep += 1
        power_in = action
        if type(power_in) == np.ndarray and len(power_in.shape) > 0:
            power_in = power_in[0]

        state = self._get_obs(power_in)

        reward, game_over = self.get_reward(state)
        self.prev_r = reward

        return state, reward, game_over, {'forces_added': None}

    def get_reward(self,state):
        game_over = False
        upright = calculate_upright_angle(-(self.data.qpos[1] + -np.pi))

        # bad_stuff = -0.1*state[0]**2 - 0.1*(upright/0.4)**2 - 0.001*state[2]**2 -0.1*state[3]**2 - 0.1*state[4]**2
        # reward = math.exp(bad_stuff)*0.1


        reward = -0.5*upright**2 + 2 - 0.1*abs(self.data.qpos[0]) #+ 0.001*self.timestep
        # reward = -0.1*state[0]**2 - 0.1*(upright/0.4)**2 - 0.5*state[2]**2 -0.1*state[3]**2 - 0.1*state[4]**2  
        # reward = self.timestep - 0.5*state[0]**2 - 0.25*(upright/0.4)**2 - 0.01*state[2]**2 -0.001*state[3]**2 - 0.001*state[4]**2  

        # reward = - 0.5*upright**2 - 0.5*self.data.qpos[0]**2 #+ 0.001*self.timestep
  
        if abs(self.data.qpos[0]) > 2.0 or abs(upright) > 0.3:
            reward = -4
            game_over = True

        return reward, game_over

    def _get_obs(self, power_in):
        joint_pos = deepcopy(self.data.qpos)

        self.prev_theta = joint_pos
        self.prev_time = self.data.time

        upright_angle = calculate_upright_angle(-(self.data.qpos[1] + -np.pi))
        joint_pos[1] = upright_angle
        state = np.append(
            np.array([joint_pos]), np.array([power_in]))

        theta = self.thetaFilter.step(self.data.qpos[0])
        alpha = self.alphaFilter.step(upright_angle)
        state = np.append(state,theta)
        state = np.append(state,alpha)

        state[0] /= 2.0
        state[1] = state[1]/0.4
        state[2] = state[2]
        state[3] = state[3] / 10.0
        state[4] = state[4] / 10.0
        # state = np.append(state, self.data.qvel[0]/10)
        # state = np.append(state, self.data.qvel[1]/10)

        state = np.clip(state, a_min=-1, a_max=1)
        return state

    def reset_model(self):
        # self.theta_state = np.random.normal(0,0.000001)
        # self.alpha_state = np.random.normal(0,0.000001)
        self.theta_state = 0
        self.alpha_state = 0
        self.prev_time = 0.0
        self.prev_theta = np.zeros(2)
        # Reset filtered derivative filters
        self.thetaFilter.reset() 
        self.alphaFilter.reset() 

        self.timestep = 0
        self.set_state(
            np.array([0.0 + np.random.normal(loc=0, scale=0.1), 0.0 + np.random.normal(loc=0, scale=0.1)]),
            np.array([0.0 + np.random.normal(loc=0, scale=0.1), 0.0 + np.random.normal(loc=0, scale=0.1)])
        )
        obs = self._get_obs(0.0)

        return obs

    def viewer_setup(self):
        v = self.viewer
        v.cam.trackbodyid = 0
        v.cam.distance = self.model.stat.extent * 0.5
        v.cam.lookat[2] = 0.12250000000000005  # v.model.stat.center[2]

    def generate_new_ts_model(self, path, ts):
        with open(path, 'r') as f:
            document = f.read()
        document = document.replace('<option timestep="0.002"/>', '<option timestep="{}"/>'.format(ts))
        path = path.replace('quanser_pendulum_single', 'quanser_pendulum_single_MOD')
        with open(path, 'w') as f:
            f.write(document)
        return path






